package com.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.Modal.Underwriter;
import com.Utils.DbConnection;

public class UnderwriterRegisterDao {
	
	public int registerUnderwriter(Underwriter underwriter ) throws SQLException{
		
		
		int check = 0;
		
		int underwriterId = underwriter.getUnderwriterId();
		String name = underwriter.getName();
		String dob = underwriter.getDateOfBirth();
		String gender = underwriter.getGender();
		String phone = underwriter.getPhoneNo();
		String jDate = underwriter.getJoiningDate();
		String password = underwriter.getPassword();
		
		Connection con = null;
		PreparedStatement pst = null;
		
		try{

			con = DbConnection.getConnect();
			
			String sql = "insert into underwriter(underwriterid,name,dob,gender,phone,joiningdate,defaultpassword) values(?,?,?,?,?,?,?)";
			pst = con.prepareStatement(sql);
			
			pst.setInt(1, underwriterId);
			pst.setString(2,name);
			pst.setString(3,dob);
			pst.setString(4,gender);
			pst.setString(5,phone);
			pst.setString(6,jDate);
			pst.setString(7,password);
			
			
			
			check = pst.executeUpdate();
			
			System.out.println(check);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		con.close();
		pst.close();
		
		return check;
		
	}
}
