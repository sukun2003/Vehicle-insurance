package com.Dao;

import com.Modal.Underwriter;
import com.Service.UnderwriterService;
import com.Utils.DbConnection;
import java.sql.*;
import java.util.ArrayList;

public class UnderwriterAuthDao {
	
	
	public static ArrayList<Underwriter> showAllUnderWriter(){
		
		try {
			Connection con = DbConnection.getConnect();
			
			String sql = "Select * from Underwriter";
			Statement s;
			s = con.createStatement();
			 ResultSet rs=s.executeQuery(sql);
			 
			 ArrayList<Underwriter> allUnderwriter = new ArrayList<>();
			 
				while(rs.next()){
					Underwriter underwriter = new Underwriter(rs.getString("name"), rs.getString("dob"), rs.getString("gender"), rs.getString("phone"), rs.getString("joiningdate"), rs.getString("defaultpassword"), rs.getInt("underwriterid"));
					allUnderwriter.add(underwriter);
				}
			 
				rs.close();
				s.close();
				con.close();
				return allUnderwriter;
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
		}
		return null;
	}
	
	public static Underwriter underwriterAuth(int username, String password) throws SQLException{
		
		Connection con = DbConnection.getConnect();
		
		String sql = "Select * from Underwriter where underwriterid = ? and defaultpassword = ?";
		
		String hashPassword = UnderwriterService.hashPassword(password);
		
		Underwriter underwriter = null;
		
		try{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, username);
			pst.setString(2, hashPassword);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()){
				underwriter = new Underwriter(rs.getString("name"), rs.getString("dob"), rs.getString("gender"), rs.getString("phone"), rs.getString("joiningdate"), rs.getString("defaultpassword"), rs.getInt("underwriterid"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
		return underwriter;
	}
	
	public static Underwriter underwriterById(int underwriterId){
		
		Connection con = DbConnection.getConnect();
		
		String sql = "Select * from Underwriter where underwriterid = ? ";
		
		
		Underwriter underwriter = null;
		
		try{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, underwriterId);
		
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()){
				underwriter = new Underwriter(rs.getString("name"), rs.getString("dob"), rs.getString("gender"), rs.getString("phone"), rs.getString("joiningdate"), rs.getString("defaultpassword"), rs.getInt("underwriterid"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return underwriter;
		
	}
	
	public static boolean updatePassword(int userId , String password , String newPassword){
		
		boolean check = false;
		try{
		
		Underwriter ud = underwriterAuth(userId , password );
		
		if(ud == null) return check;
		
		String hashPassword = UnderwriterService.hashPassword(newPassword);
		String query = "update Underwriter set defaultpassword = ? where underwriterid = ? ";
		Connection con = DbConnection.getConnect();
		PreparedStatement pst = con.prepareStatement(query);
		
		pst.setString(1, hashPassword);
		pst.setInt(2, userId);
		 check = pst.executeUpdate()>0?true:false;
		
		 
		con.close();
		}
		catch(Exception e){
			
		}
		
		return check;
	}
}
