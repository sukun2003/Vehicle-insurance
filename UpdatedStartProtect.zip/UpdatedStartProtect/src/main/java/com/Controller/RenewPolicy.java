package com.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.PolicyDao;
import com.Modal.Insurance;

/**
 * Servlet implementation class RenewPolicy
 */
@WebServlet("/renewPolicy")
public class RenewPolicy extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public RenewPolicy() {
        super();
    }

    /**
     * Handles GET requests - Fetches the policy and redirects to policyDetails.jsp
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int policyNumber = Integer.parseInt(request.getParameter("policyNo"));

            // Fetch policy details
            Insurance policy = PolicyDao.getPolicyByPolicyNumber(policyNumber);

            if (policy != null) {
                // Send policy details to policyDetails.jsp
                request.setAttribute("policy", policy);
                request.getRequestDispatcher("policyDetails.jsp").forward(request, response);
                System.out.println(policy.toString());
            } else {
                // If policy does not exist, show an error message
                request.setAttribute("errorMessage", "Policy Not Found!");
                request.getRequestDispatcher("renewPolicy.jsp").forward(request, response);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid Policy Number!");
            request.getRequestDispatcher("renewPolicy.jsp").forward(request, response);
        }
    }

    /**
     * Handles POST requests - Redirects to payment page after form submission
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int policyNumber = Integer.parseInt(request.getParameter("policyNo"));
        
        // Redirect to payment page
        response.sendRedirect("PaymentPage.jsp?policyNo=" + policyNumber);
    }
}
