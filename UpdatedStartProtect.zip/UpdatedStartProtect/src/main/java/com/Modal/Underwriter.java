package com.Modal;

public class Underwriter {
	
	@Override
	public String toString() {
		return "Underwriter [underwriterId=" + underwriterId + ", name=" + name + ", dateOfBirth=" + dateOfBirth
				+ ", gender=" + gender + ", phoneNo=" + phoneNo + ", joiningDate=" + joiningDate + ", password="
				+ password + "]";
	}

	private int underwriterId;
	private String name;
	private String dateOfBirth;
	private String gender;
	private String phoneNo;
	private String joiningDate;
	private String password;
	
	public Underwriter(String name, String dateOfBirth, String gender, String phoneNo, String joiningDate,
			String password, int underwriterId) {
		super();
		this.underwriterId = underwriterId;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.phoneNo = phoneNo;
		this.joiningDate = joiningDate;
		this.password = password;
	}

	public int getUnderwriterId() {
		return underwriterId;
	}

	public void setUnderwriterId(int underwriterId) {
		this.underwriterId = underwriterId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
