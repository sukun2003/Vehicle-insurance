package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.Modal.Insurance;
import com.Modal.Underwriter;
import com.Utils.DbConnection;

public class PolicyDao {

	
	 public static boolean savePolicy(Insurance policy) {
	        String sql = "INSERT INTO Insurance (policyNo, vehicleNo, vehicleType, customerName, engineNo, chasisNo, phoneNo, type, premiumAmt, fromDate, toDate, underwriterId, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	        try (Connection conn = DbConnection.getConnect();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {

	            stmt.setInt(1, policy.getPolicyNo());
	            stmt.setString(2, policy.getVehicleNo());
	            stmt.setString(3, policy.getVehicleType());
	            stmt.setString(4, policy.getCustomerName());
	            stmt.setInt(5, policy.getEngineNo());
	            stmt.setInt(6, policy.getChasisNo());
	            stmt.setLong(7, policy.getPhoneNo());
	            stmt.setString(8, policy.getType());
	            stmt.setInt(9, policy.getPremiumAmt());
	            stmt.setString(10, policy.getFromDate());
	            stmt.setString(11, policy.getToDate());
	            stmt.setString(12, policy.getUnderwriterId());
	            stmt.setString(13, policy.getStatus());

	            int rowsInserted = stmt.executeUpdate();
	            return rowsInserted > 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
	 
	 public static ArrayList<Insurance> showAllPolicy(){
			
			try {
				Connection con = DbConnection.getConnect();
				
				String sql = "Select * from Insurance";
				Statement s;
				s = con.createStatement();
				 ResultSet rs=s.executeQuery(sql);
				 
				 ArrayList<Insurance> allPolicy = new ArrayList<>();
				 
					while(rs.next()){
						 Insurance policy = new Insurance(rs.getInt("policyNo"),rs.getString("vehicleNo"),rs.getString("vehicleType"), rs.getString("customerName"), rs.getInt("engineNo"),
								 rs.getInt("chasisNo"), rs.getLong("phoneNo"), rs.getString("type"), rs.getInt("premiumAmt"), rs.getString("fromDate"),rs.getString("toDate"),
					    			rs.getString("underwriterId"), rs.getString("status"));
						 allPolicy.add(policy);
					}
				 
					rs.close();
					s.close();
					con.close();
					return allPolicy;
					
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
	 
	 
	 public static ArrayList<Insurance> showUnderWriterPolicies(int underwriterId){
		 
		 ArrayList<Insurance> allPolicies = new ArrayList<>();
		 
		 try{
			 Connection con = DbConnection.getConnect();
			 String sql = "Select * from Insurance where underwriterId = ?";
				PreparedStatement pst;
				pst = con.prepareStatement(sql);
				pst.setString(1, underwriterId+"");
				ResultSet rs = pst.executeQuery();
				
			
				 
				 
					while(rs.next()){
						 Insurance policy = new Insurance(rs.getInt("policyNo"),rs.getString("vehicleNo"),rs.getString("vehicleType"), rs.getString("customerName"), rs.getInt("engineNo"),
								 rs.getInt("chasisNo"), rs.getLong("phoneNo"), rs.getString("type"), rs.getInt("premiumAmt"), rs.getString("fromDate"),rs.getString("toDate"),
					    			rs.getString("underwriterId"), rs.getString("status"));
						 allPolicies.add(policy);
					}
				 
					rs.close();
					pst.close();
					con.close();
			 
		 }catch(Exception e){
			 
			 System.out.print("Error: inside policy dao");
			 e.printStackTrace();
		 }
		 
		 return allPolicies;
		 
		 
	 }
	 
	 
	 public static int getNewPolicyNumber(){
 
		 int policyNumber = -1;
		 
		 try{
			 Connection con = DbConnection.getConnect();
			 String sql = "Select count(policyNo) from Insurance";
				PreparedStatement pst;
				pst = con.prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
				
			
				 
				 
				if(rs.next()){
					policyNumber = rs.getInt(1) + 1;
				}
				
				 
					rs.close();
					pst.close();
					con.close();
			 
		 }catch(Exception e){
			 System.out.print("Error: inside policy dao");
			 e.printStackTrace();
		 }
		 
		 return policyNumber;
	 }
	 

	 public static Insurance getPolicyByPolicyNumber(int policyNumber){
		 Insurance policy = null;
			try {
				Connection con = DbConnection.getConnect();
				
				String sql = "Select * from Insurance where policyNo = ?";
				PreparedStatement s;
				s = con.prepareStatement(sql);
				
				s.setInt(1, policyNumber);
				 ResultSet rs=s.executeQuery();
				 
				
					if(rs.next()){
						policy = new Insurance(rs.getInt("policyNo"),rs.getString("vehicleNo"),rs.getString("vehicleType"), rs.getString("customerName"), rs.getInt("engineNo"),
								 rs.getInt("chasisNo"), rs.getLong("phoneNo"), rs.getString("type"), rs.getInt("premiumAmt"), rs.getString("fromDate"),rs.getString("toDate"),
					    			rs.getString("underwriterId"), rs.getString("status"));
						
					}
				 
					rs.close();
					s.close();
					con.close();
					return policy;
					
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.print("Policy Dao -> getPolicyByPolicyNumber "+e.getMessage());
				e.printStackTrace();
			}
			return null;
		}
	 
	 
	 public static boolean expirePolicyUpdation(){
		 
		 String sql = "update insurance set status='expired' where toDate < CURRENT_DATE";
		 Connection con = DbConnection.getConnect();
		try {
			Statement stmt  = con.createStatement();
			int rows = stmt.executeUpdate(sql);
			stmt.close();
			con.close();
			if(rows > 0) return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		 
		 return false;
	 }


}

